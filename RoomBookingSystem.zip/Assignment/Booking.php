<?php ob_start();session_start(); ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Bootstrap Example</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<style>
    #design{
        background-image: url('images/container.jpg');
    }
</style>
<body>

<nav class="navbar navbar-default">
    <div class="container-fluid">
        <div class="navbar-header">
            <a class="navbar-brand" href="Homepage.php">Berkeley College</a>
        </div>
        <ul class="nav navbar-nav">
          

            <?php
            if (isset($_SESSION['email']) && !empty($_SESSION["email"])){
                echo <<<_EOF
                <li><a href="Booking.php">Book </a></li>

                 <li class="dropdown">
                    <a class="dropdown-toggle" data-toggle="dropdown"> Account
                    <span class="caret"></span></a>
                        <ul class="dropdown-menu">
                             <li><a href="UserProfile.php"> Profile </a></li>
                             <li><a href="BookingHistory.php">Booking History</a></li>
                             <li><a href="Logout.php">Logout</a></li>
                        </ul>
                 </li>

_EOF;

            }
            else{
                echo <<<_EOF

            <li class="dropdown">
                <a class="dropdown-toggle" data-toggle="dropdown" href="#">Account
                    <span class="caret"></span></a>
                <ul class="dropdown-menu">
                    <li><a href="LoginPage.php">Login </a></li>
                    <li><a href="Registration.php">Registration</a></li>
                </ul>
            </li>
_EOF;
            }
            ?>

        </ul>
    </div>
</nav>



        <?php

        $db = mysqli_connect('localhost', 'root', '', 'study_room');

        if ($db->connect_error) {
            die("Connection failed: " . $db->connect_error);
        }

        $sql = "SELECT * FROM room WHERE status='available'";
        $result = mysqli_query($db, $sql);

        if($result ->num_rows > 0){

            while($row = mysqli_fetch_array($result)) {
                echo "<form method='post' action='BookingProcess.php'>";
                echo "<div class='container'>";
                echo "<div id='design' class='jumbotron'>";
    
                echo "<h3><b>"."Level: "."$row[level]"."</b></h3>";
                echo "<p><i>"."Capacity: "."$row[capacity]"."</i></p>";
                echo "<p><i>"."Date: "."$row[date]"."</i></p>";
    

                echo "<input type='hidden' name='room_id' value='".$row["id"]."' >";
                echo "<input type='hidden' name='level' value='".$row["level"]."' >";
                echo "<input type='hidden' name='capacity' value='".$row["capacity"]."' >";
                echo "<input type='hidden' name='date' value='".$row["date"]."' >";
                echo "<input type='hidden' name='status' value='".$row["status"]."' >";
               
                echo "<button type='submit' class='btn btn-primary' name='id'> Book Now</button>";
                echo "</div>";
                echo "</div>";
                echo "</form>";
    
            }
            
        }else{
            echo"<div class='alert alert-danger' role='alert'>";
            echo "No rooms available temporarily";
            echo "</div>";
    
        }

        ?>

       

</div>

</body>
</html>

<?php ob_start();session_start(); ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Bootstrap Example</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>

<nav class="navbar navbar-default">
    <div class="container-fluid">
        <div class="navbar-header">
            <a class="navbar-brand" href="Homepage.php">Berkeley College</a>
        </div>
        <ul class="nav navbar-nav">
       

            <?php
            if (isset($_SESSION['email']) && !empty($_SESSION["email"])){
                echo <<<_EOF
                <li><a href="Booking.php">Book </a></li>

                 <li class="dropdown">
                    <a class="dropdown-toggle" data-toggle="dropdown"> Account
                    <span class="caret"></span></a>
                        <ul class="dropdown-menu">
                             <li><a href="UserProfile.php"> Profile </a></li>
                             <li><a href="BookingHistory.php">Booking History</a></li>
                             <li><a href="Logout.php">Logout</a></li>
                        </ul>
                 </li>

_EOF;

            }
            else{
                echo <<<_EOF

            <li class="dropdown">
                <a class="dropdown-toggle" data-toggle="dropdown" href="#">Account
                    <span class="caret"></span></a>
                <ul class="dropdown-menu">
                    <li><a href="LoginPage.php">Login </a></li>
                    <li><a href="Registration.php">Registration</a></li>
                </ul>
            </li>
_EOF;
            }
            ?>

        </ul>
    </div>
</nav>

<?php

    $db = mysqli_connect('localhost', 'root', '', 'study_room');

    if ($db->connect_error) {
        die("Connection failed: " . $db->connect_error);
    }
    $id = $_SESSION['id'];

    $sql = "SELECT * FROM history WHERE userId = '$id'";


    $result = mysqli_query($db, $sql);

    if($result ->num_rows > 0){

        $counter = 1;

        echo "<div class='container'>";
        echo" <h2>History </h2>";
        echo "<table class='table table-hover'>

        <thead>
        <tr>
            <th>No.</th>
            <th>Booking Receipt</th>
            <th>Room level </th>
            <th>Room Capacity</th>
            <th>Date</th>
        </tr>
        </thead>";

        while($row = mysqli_fetch_array($result)) {
            echo "<form method='post'>";
            echo "<tbody>";
            echo "<tr>";
            echo "<td>"."$counter"." </td>";
            echo "<td>"."$row[bookingId]"." </td>";
            echo "<td>"."$row[roomLevel]"." </td>";
            echo "<td>"."$row[roomCapacity]"." </td>";
            echo "<td>"."$row[roomDate]"." </td>";
            echo "</tr>";
            echo "</tbody>";
            echo "</form>";

            $counter++;
        }
        echo "</table>";
        echo "</div>";

    }else{
        echo"<div class='alert alert-danger' role='alert'>";
        echo "No results found";
        echo "</div>";

    }

?>

</body>
</html>

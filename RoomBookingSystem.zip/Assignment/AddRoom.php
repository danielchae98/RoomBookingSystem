<?php session_start(); ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Bootstrap Example</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>

<nav class="navbar navbar-default">
    <div class="container-fluid">
        <div class="navbar-header">
            <a class="navbar-brand" href="AdminPage.php">Berkeley College</a>
        </div>
        <ul class="nav navbar-nav">
            <li class="dropdown">
                <a class="dropdown-toggle" data-toggle="dropdown" href="#">Activity
                    <span class="caret"></span></a>
                <ul class="dropdown-menu">
                    <li><a href="AddRoom.php">Add new room</a></li>
                    <li><a href="BookingRequest.php">Booking request</a></li>
                    <li><a href="ViewUsers.php">View all users</a></li>
                </ul>
            </li>



            <li class="dropdown">
                <a class="dropdown-toggle" data-toggle="dropdown" href="#">Account
                    <span class="caret"></span></a>
                <ul class="dropdown-menu">
                    <li><a href="Logout.php">Logout</a></li>
                </ul>
            </li>

        </ul>
    </div>
</nav>

<div class="container">
    <h2>Add new room</h2>
    <form action="AddRoom.php" method="post">

        <?php

            $db = mysqli_connect('localhost', 'root', '', 'study_room');

            if ($db->connect_error) {
                die("Connection failed: " . $db->connect_error);
            }

            if(isset($_POST['add'])){

                $level = $_POST['level'];
                $capacity = $_POST['capacity'];
                $date = $_POST['date'];

              
            
                        $sql = "INSERT into room (level, capacity, date, status)
                                    VALUES ('$level','$capacity','$date','available')";
                        $result = mysqli_query($db, $sql);

                        if ($result === TRUE) {

                            echo "<div class='alert alert-success'>";
                            echo "New room added successfully";
                            echo "</div>";
                            header( "refresh:1;url=AddRoom.php" );
                        } else {
                            echo "<script type='text/javascript'>alert('Failed');</script>" . $sql . "<br>" . $db->error;
                        }
                    
             
            }
        ?>

        <div class="form-group">
            <label for="email">Level:</label>
            <input type="number" class="form-control" id="level" placeholder="Enter level" name="level" required>
        </div>


        <div class="form-group">
            <label for="email">Capacity:</label>
            <input type="number" class="form-control" id="capacity" placeholder="Enter capacity" name="capacity" required >
        </div>

        <div class="form-group">
            <label for="email">Date:</label>
            <input type="date" class="form-control" id="date" placeholder="Enter date" name="date" required>
        </div>


        <input type="submit" class="btn btn-default" name="add" value="Add"/>
    </form>
</div>



</body>
</html>

<?php  session_start();
    ob_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Bootstrap Example</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>

<nav class="navbar navbar-default">
    <div class="container-fluid">
        <div class="navbar-header">
            <a class="navbar-brand" href="Homepage.php">Berkeley College</a>
        </div>
        <ul class="nav navbar-nav">
          

            <?php
            if (isset($_SESSION['email']) && !empty($_SESSION["email"])){
                echo <<<_EOF
                <li><a href="Booking.php">Book </a></li>

                 <li class="dropdown">
                    <a class="dropdown-toggle" data-toggle="dropdown"> Account
                    <span class="caret"></span></a>
                        <ul class="dropdown-menu">
                             <li><a href="UserProfile.php"> Profile </a></li>
                             <li><a href="BookingHistory.php">Booking History</a></li>
                             <li><a href="Logout.php">Logout</a></li>
                        </ul>
                 </li>

_EOF;

            }
            else{
                echo <<<_EOF

            <li class="dropdown">
                <a class="dropdown-toggle" data-toggle="dropdown" href="#">Account
                    <span class="caret"></span></a>
                <ul class="dropdown-menu">
                    <li><a href="LoginPage.php">Login </a></li>
                    <li><a href="Registration.php">Registration</a></li>
                </ul>
            </li>
_EOF;
            }
            ?>

        </ul>
    </div>
</nav>



<?php 

    $_SESSION['room_id'] = $_POST['room_id'];
    $_SESSION['level'] = $_POST['level'];
    $_SESSION['capacity'] = $_POST['capacity'];
    $_SESSION['date'] = $_POST['date'];

    $user_id = $_SESSION['id'];
    $roomId = $_SESSION['room_id'];
    $roomLevel = $_SESSION['level'];
    $capacity = $_SESSION['capacity'];
    $date = $_SESSION['date'];


    $db = mysqli_connect('localhost', 'root', '', 'study_room');

        if ($db->connect_error) {
            die("Connection failed: " . $db->connect_error);
        }

        $sql = "INSERT INTO bookingprocess (userId, roomId, roomLevel, roomCapacity, roomDate, status)
                    VALUES ('$user_id','$roomId','$roomLevel','$capacity','$date','pending')";

        $result = mysqli_query($db, $sql);

        if ($result === TRUE){  
            $sql = "UPDATE room SET status ='booked' WHERE id ='".$roomId."'";
            $fetchResult = mysqli_query($db,$sql);
            echo "<div class='alert alert-success' role='alert'>";
            echo "Booked Successful";
            echo "</div>";
            header( "refresh:1;url=Homepage.php" );
        }

?>

</div>

</body>
</html>

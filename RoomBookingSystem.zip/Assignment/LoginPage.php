<?php ob_start();session_start(); ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Bootstrap Example</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>

<nav class="navbar navbar-default">
    <div class="container-fluid">
        <div class="navbar-header">
            <a class="navbar-brand" href="Homepage.php">Berkeley College</a>
        </div>
        <ul class="nav navbar-nav">
      

            <?php
            if (isset($_SESSION['email']) && !empty($_SESSION["email"])){
                echo <<<_EOF
                <li><a href="Booking.php">Book </a></li>

                 <li class="dropdown">
                    <a class="dropdown-toggle" data-toggle="dropdown"> Account
                    <span class="caret"></span></a>
                        <ul class="dropdown-menu">
                             <li><a href="UserProfile.php"> Profile </a></li>
                             <li><a href="BookingHistory.php">Booking History</a></li>
                             <li><a href="Logout.php">Logout</a></li>
                        </ul>
                 </li>

_EOF;

            }
            else{
                echo <<<_EOF

            <li class="dropdown">
                <a class="dropdown-toggle" data-toggle="dropdown" href="#">Account
                    <span class="caret"></span></a>
                <ul class="dropdown-menu">
                    <li><a href="LoginPage.php">Login </a></li>
                    <li><a href="Registration.php">Registration</a></li>
                </ul>
            </li>
_EOF;
            }
            ?>

        </ul>
    </div>
</nav>


<div class="container">
    <h2>Sign in to your account </h2>
    <form action="LoginPage.php" method="POST">

        <?php

        $db = mysqli_connect('localhost', 'root', '', 'study_room');
        if ($db->connect_error) {
            die("Connection failed: " . $db->connect_error);
        }

        if(isset($_POST['login'])){

            $email = $_POST['email'];
            $password = $_POST['password'];

            $sql = "SELECT * FROM account WHERE email='$email' AND password='$password'";
            $result = mysqli_query($db, $sql);
            $row = mysqli_fetch_array($result);



            if(mysqli_num_rows($result) == true){
                $_SESSION['password'] = $password;
                $_SESSION['id'] = $row['id'];
                $_SESSION['email'] = $email;

                echo "<div class='alert alert-success' role='alert'>";
                echo "Login Successful";
                echo "</div>";

                header( "refresh:1;url=Homepage.php" );

            }        
            else{

                echo "<div class='alert alert-danger' role='alert'>";
                echo "Wrong username or password combination ";
                echo "</div>";
            }

            $sql2 = "SELECT * FROM account WHERE email='$email' AND password='$password' AND contactNum = '012-4645358'";
            $result2 = mysqli_query($db, $sql2);

            if(mysqli_num_rows($result2) == true){
      
                header( "refresh:1;url=AdminPage.php" );

            }

        }

        ?>

        <div class="form-group">
            <label for="email">Email:</label>
            <input type="email" class="form-control"  placeholder="Enter email" name="email" required>
        </div>

        <div class="form-group">
            <label for="pwd">Password:</label>
            <input type="password" class="form-control" placeholder="Enter password" name="password" required>
        </div>

        <button type="submit" class="btn btn-default" name="login">Log In</button>
    </form>
</div>



</body>
</html>

<?php  session_start(); ob_start(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Bootstrap Example</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

    <script src="https://canvasjs.com/assets/script/jquery-1.11.1.min.js"></script>
    <script src="https://canvasjs.com/assets/script/jquery-ui.1.11.2.min.js"></script>
    <script src="https://canvasjs.com/assets/script/jquery.canvasjs.min.js"></script>
    <link href="https://canvasjs.com/assets/css/jquery-ui.1.11.2.min.css" rel="stylesheet" />

</head>
<body>

<nav class="navbar navbar-default">
    <div class="container-fluid">
        <div class="navbar-header">
            <a class="navbar-brand" href="AdminPage.php">Berkeley College</a>
        </div>
        <ul class="nav navbar-nav">
            <li class="dropdown">
                <a class="dropdown-toggle" data-toggle="dropdown" href="#">Activity
                    <span class="caret"></span></a>
                <ul class="dropdown-menu">
                    <li><a href="AddRoom.php">Add new room</a></li>
                    <li><a href="BookingRequest.php">Booking request</a></li>
                    <li><a href="ViewUsers.php">View all users</a></li>
                </ul>
            </li>



            <li class="dropdown">
                <a class="dropdown-toggle" data-toggle="dropdown" href="#">Account
                    <span class="caret"></span></a>
                <ul class="dropdown-menu">
                    <li><a href="Logout.php">Logout</a></li>
                </ul>
            </li>

        </ul>
    </div>
</nav>



<?php 
   

        $_SESSION['bookingNum'] = $_POST["bookingNum"];
        $_SESSION['userId'] = $_POST['userId'];
        $_SESSION['roomId'] = $_POST['roomId'];
        $_SESSION['roomLevel'] = $_POST['roomLevel'];
        $_SESSION['roomCapacity'] = $_POST['roomCapacity'];
        $_SESSION['roomDate'] = $_POST['roomDate'];

        $bookingNum = $_SESSION['bookingNum'];
        $userId = $_SESSION['userId'];
        $roomId = $_SESSION['roomId']; 
        $roomLevel = $_SESSION['roomLevel']; 
        $roomCapacity = $_SESSION['roomCapacity']; 
        $roomDate = $_SESSION['roomDate']; 



    $db = mysqli_connect('localhost', 'root', '', 'study_room');

        if ($db->connect_error) {
            die("Connection failed: " . $db->connect_error);
        }

        

        $sql = "UPDATE bookingprocess SET status ='verified' WHERE bookingNum = $bookingNum";

        $result = mysqli_query($db, $sql);

        if ($result === TRUE){  
            
            $sql = "INSERT INTO history (bookingId, userId, roomId, roomLevel, roomCapacity, roomDate)
            VALUES ('$bookingNum','$userId', '$roomId', '$roomLevel','$roomCapacity','$roomDate')";
            $fetchResult = mysqli_query($db,$sql);
            echo "<div class='alert alert-success' role='alert'>";
            echo "Approved Successful";
            echo "</div>";
            header( "refresh:1;url=BookingRequest.php" );
        }

?>

</div>

</body>
</html>

-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 08, 2018 at 06:12 AM
-- Server version: 10.1.28-MariaDB
-- PHP Version: 7.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `study_room`
--

-- --------------------------------------------------------

--
-- Table structure for table `account`
--

CREATE TABLE `account` (
  `id` int(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `contactNum` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `account`
--

INSERT INTO `account` (`id`, `email`, `contactNum`, `password`) VALUES
(1, 'danielmunchun98@gmail.com', '012-7208135', '12345'),
(2, 'admin@gmail.com', '012-4645358', '12345'),
(4, 'daniel@gmail.com', '012-8742315', '1234'),
(5, 'daniel_munchun@hotmail.com', '012-9424234', '123');

-- --------------------------------------------------------

--
-- Table structure for table `bookingprocess`
--

CREATE TABLE `bookingprocess` (
  `bookingNum` int(11) NOT NULL,
  `userId` int(255) NOT NULL,
  `roomId` int(255) NOT NULL,
  `roomLevel` int(255) NOT NULL,
  `roomCapacity` int(255) NOT NULL,
  `roomDate` date NOT NULL,
  `status` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bookingprocess`
--

INSERT INTO `bookingprocess` (`bookingNum`, `userId`, `roomId`, `roomLevel`, `roomCapacity`, `roomDate`, `status`) VALUES
(25, 1, 26, 4, 5, '2018-12-12', 'verified');

-- --------------------------------------------------------

--
-- Table structure for table `history`
--

CREATE TABLE `history` (
  `historyId` int(255) NOT NULL,
  `bookingId` int(255) NOT NULL,
  `userId` int(255) NOT NULL,
  `roomId` int(255) NOT NULL,
  `roomLevel` int(255) NOT NULL,
  `roomCapacity` int(255) NOT NULL,
  `roomDate` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `history`
--

INSERT INTO `history` (`historyId`, `bookingId`, `userId`, `roomId`, `roomLevel`, `roomCapacity`, `roomDate`) VALUES
(14, 25, 1, 26, 4, 5, '2018-12-12');

-- --------------------------------------------------------

--
-- Table structure for table `room`
--

CREATE TABLE `room` (
  `id` int(11) NOT NULL,
  `level` int(255) NOT NULL,
  `capacity` int(255) NOT NULL,
  `date` date NOT NULL,
  `status` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `room`
--

INSERT INTO `room` (`id`, `level`, `capacity`, `date`, `status`) VALUES
(26, 4, 5, '2018-12-12', 'booked'),
(27, 5, 2, '2018-12-13', 'available'),
(28, 6, 8, '2018-12-20', 'available'),
(29, 7, 5, '2018-12-20', 'available'),
(30, 10, 5, '2018-12-31', 'available');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `account`
--
ALTER TABLE `account`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `bookingprocess`
--
ALTER TABLE `bookingprocess`
  ADD PRIMARY KEY (`bookingNum`);

--
-- Indexes for table `history`
--
ALTER TABLE `history`
  ADD PRIMARY KEY (`historyId`);

--
-- Indexes for table `room`
--
ALTER TABLE `room`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `account`
--
ALTER TABLE `account`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `bookingprocess`
--
ALTER TABLE `bookingprocess`
  MODIFY `bookingNum` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `history`
--
ALTER TABLE `history`
  MODIFY `historyId` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `room`
--
ALTER TABLE `room`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

<?php session_start(); ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Bootstrap Example</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>

<nav class="navbar navbar-default">
    <div class="container-fluid">
        <div class="navbar-header">
            <a class="navbar-brand" href="Homepage.php">Berkeley College</a>
        </div>
        <ul class="nav navbar-nav">
         

            <?php
            if (isset($_SESSION['email']) && !empty($_SESSION["email"])){
                echo <<<_EOF
                <li><a href="Booking.php">Book </a></li>

                 <li class="dropdown">
                    <a class="dropdown-toggle" data-toggle="dropdown"> Account
                    <span class="caret"></span></a>
                        <ul class="dropdown-menu">
                             <li><a href="UserProfile.php"> Profile </a></li>
                             <li><a href="BookingHistory.php">Booking History</a></li>
                             <li><a href="Logout.php">Logout</a></li>
                        </ul>
                 </li>

_EOF;

            }
            else{
                echo <<<_EOF

            <li class="dropdown">
                <a class="dropdown-toggle" data-toggle="dropdown" href="#">Account
                    <span class="caret"></span></a>
                <ul class="dropdown-menu">
                    <li><a href="LoginPage.php">Login </a></li>
                    <li><a href="Registration.php">Registration</a></li>
                </ul>
            </li>
_EOF;
            }
            ?>

        </ul>
    </div>
</nav>


<div class="container" >
    <div class="jumbotron" style="background:url('images/index.png');">
        <h1>Berkeley College</h1>
        <p>Expand your career possibilities while managing your costs</p>
    </div>


    <p>Accredited by Middle States Commission on Higher Education, 3624 Market Street,
     Philadelphia, PA 19104, 267-284-5000. Accreditation was last reaffirmed in June 2018. 
     The Middle States Commission on Higher Education is an institutional accrediting agency 
     recognized by the U.S. Secretary of Education and the Council for Higher Education Accreditation.
    </p>
    <p>Berkeley College reserves the right to add, discontinue, or modify its programs and policies at 
    any time. Visit this website, BerkeleyCollege.edu, for the most up-to-date information. For more 
    information about Berkeley College graduation rates, the median debt of students who completed programs, 
    and other important disclosures, please visit BerkeleyCollege.edu/disclosures/.
    </p>

    <p>
    $45+ million in Berkeley College institutional aid was provided to qualified students during the 2017-2018 award year
    </p>

    <p>
    7,000+ students, including more than 350 international students representing over 50 countries 
    (not included in these figures are over 150 international students, representing 5 countries, 
    attending as part of a J1 visitor exchange program)
    </p>


</div>


</body>
</html>


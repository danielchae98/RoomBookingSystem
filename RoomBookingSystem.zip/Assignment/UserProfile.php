<?php ob_start();session_start(); ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Bootstrap Example</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>

<nav class="navbar navbar-default">
    <div class="container-fluid">
        <div class="navbar-header">
            <a class="navbar-brand" href="Homepage.php">Berkeley College</a>
        </div>
        <ul class="nav navbar-nav">
       

            <?php
            if (isset($_SESSION['email']) && !empty($_SESSION["email"])){
                echo <<<_EOF
                <li><a href="Booking.php">Book </a></li>

                 <li class="dropdown">
                    <a class="dropdown-toggle" data-toggle="dropdown"> Account
                    <span class="caret"></span></a>
                        <ul class="dropdown-menu">
                             <li><a href="UserProfile.php"> Profile </a></li>
                             <li><a href="BookingHistory.php">Booking History</a></li>
                             <li><a href="Logout.php">Logout</a></li>
                        </ul>
                 </li>

_EOF;

            }
            else{
                echo <<<_EOF

            <li class="dropdown">
                <a class="dropdown-toggle" data-toggle="dropdown" href="#">Account
                    <span class="caret"></span></a>
                <ul class="dropdown-menu">
                    <li><a href="LoginPage.php">Login </a></li>
                    <li><a href="Registration.php">Registration</a></li>
                </ul>
            </li>
_EOF;
            }
            ?>

        </ul>
    </div>
</nav>



<div class="container">
    <h2>Profile Information</h2>
</div><br/>

<div class="container">
    <form action="UserProfile.php" method="post">

        <?php

        $db = mysqli_connect('localhost', 'root', '', 'study_room');

        if ($db->connect_error) {
            die("Connection failed: " . $db->connect_error);
        }

        $id = $_SESSION['id'];
        $sql = "SELECT * FROM account WHERE id='$id'";
        $result= mysqli_query($db,$sql);
        $row = mysqli_fetch_array($result);

        ?>

        <div class="form-group">

            <label for="email">Email:</label>
            <div class="panel panel-default">
                <div class="panel-body"><?php echo $row['1']; ?></div>
            </div>

            <label for="email">Contact Number:</label>
            <div class="panel panel-default">
                <div class="panel-body"><?php echo $row['2']; ?></div>
            </div>

        </div>

    </form>
</div>



</body>
</html>

<?php ob_start();session_start(); ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Bootstrap Example</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>

<nav class="navbar navbar-default">
    <div class="container-fluid">
        <div class="navbar-header">
            <a class="navbar-brand" href="Homepage.php">Berkeley College</a>
        </div>
        <ul class="nav navbar-nav">
     

            <?php
            if (isset($_SESSION['email']) && !empty($_SESSION["email"])){
                echo <<<_EOF
                <li><a href="Booking.php">Book </a></li>

                 <li class="dropdown">
                    <a class="dropdown-toggle" data-toggle="dropdown"> Account
                    <span class="caret"></span></a>
                        <ul class="dropdown-menu">
                             <li><a href="UserProfile.php"> Profile </a></li>
                             <li><a href="BookingHistory.php">Booking History</a></li>
                             <li><a href="Logout.php">Logout</a></li>
                        </ul>
                 </li>

_EOF;

            }
            else{
                echo <<<_EOF

            <li class="dropdown">
                <a class="dropdown-toggle" data-toggle="dropdown" href="#">Account
                    <span class="caret"></span></a>
                <ul class="dropdown-menu">
                    <li><a href="LoginPage.php">Login </a></li>
                    <li><a href="Registration.php">Registration</a></li>
                </ul>
            </li>
_EOF;
            }
            ?>

        </ul>
    </div>
</nav>

<div class="container">
    <h2>Registration</h2>
    <form action="Registration.php" method="post">

        <?php

        $db = mysqli_connect('localhost', 'root', '', 'study_room');

        if ($db->connect_error) {
            die("Connection failed: " . $db->connect_error);
        }

        if(isset($_POST['register'])) {

            $email = $_POST['email'];
            $contactNum = $_POST['contactNum'];
            $password = $_POST['password'];
            $password2 = $_POST['password2'];


            $sql = "SELECT * FROM account WHERE email='$email'";
            $check = mysqli_query($db, $sql);

            $sql = "SELECT * FROM account WHERE contactNum='$contactNum'";
            $check2 = mysqli_query($db, $sql);

       
            if (mysqli_num_rows($check)>0) {
                echo"<div class='alert alert-danger' role='alert'>";
                echo "This email already exists";
                echo "</div>";

            }
            elseif (mysqli_num_rows($check2)>0) {

                echo "<div class='alert alert-danger' role='alert'>";
                echo "This contact number already exists";
                echo "</div>";
            }

            else{

                if ($password != $password2) {

                    echo"<div class='alert alert-danger' role='alert'>";
                    echo "Two password does not match";
                    echo "</div>";

                } else {

                    $sql = "INSERT INTO account (email, contactNum, password) VALUES ('$email', '$contactNum', '$password')";
                    $result = mysqli_query($db, $sql);

                    if ($result === TRUE) {

                        echo"<div class='alert alert-success' role='alert'>";
                        echo "Registered successfully";
                        echo "</div>";

                        header("refresh:1;url=LoginPage.php");
                    } else {

                        echo"<div class='alert alert-danger' role='alert'>";
                        echo "Register failed";
                        echo "</div>";

                    }
                }
            }

        }
        ?>

        <div class="form-group">
            <label for="email">Email:</label>
            <input type="email" class="form-control" id="email" placeholder="Enter email" name="email" required>
        </div>

        <div class="form-group">
            <label for="email">Contact Number:</label>
            <input type="tel" class="form-control" id="contact" placeholder="Enter contact number" name="contactNum" required>
        </div>


        <div class="form-group">
            <label for="pwd">Password:</label>
            <input type="password" class="form-control" id="pwd" placeholder="Enter password" name="password" required >
        </div>

        <div class="form-group">
            <label for="pwd">Confirm Password:</label>
            <input type="password" class="form-control" id="pwd" placeholder="Confirm password" name="password2" required >
        </div>

        <button type="submit" class="btn btn-default" name="register">Register </button>
    </form>
</div>

</body>
</html>

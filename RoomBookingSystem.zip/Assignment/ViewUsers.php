<?php session_start(); ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Bootstrap Example</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>

<nav class="navbar navbar-default">
    <div class="container-fluid">
        <div class="navbar-header">
            <a class="navbar-brand" href="AdminPage.php">Berkeley College</a>
        </div>
        <ul class="nav navbar-nav">
            <li class="dropdown">
                <a class="dropdown-toggle" data-toggle="dropdown" href="#">Activity
                    <span class="caret"></span></a>
                <ul class="dropdown-menu">
                    <li><a href="AddRoom.php">Add new room</a></li>
                    <li><a href="BookingRequest.php">Booking request</a></li>
                    <li><a href="ViewUsers.php">View all users</a></li>
                </ul>
            </li>



            <li class="dropdown">
                <a class="dropdown-toggle" data-toggle="dropdown" href="#">Account
                    <span class="caret"></span></a>
                <ul class="dropdown-menu">
                    <li><a href="Logout.php">Logout</a></li>
                </ul>
            </li>

        </ul>
    </div>
</nav>

<?php
    $db = mysqli_connect('localhost','root','','study_room');

    $sql = "SELECT * FROM account WHERE email <> 'admin@gmail.com'";
    $result = mysqli_query($db, $sql);

    if($result ->num_rows > 0){

        echo "<div class='container'>";
        echo" <h2>All Users </h2>";
        echo "<table class='table table-hover'>

        <thead>
        <tr>
            <th>User ID </th>
            <th>Email</th>
            <th>Contact Number</th>
            <th>Status</th>
        </tr>
        </thead>";

        while($row = mysqli_fetch_array($result)) {
            echo "<form method='post'>";
            echo "<tbody>";
            echo "<tr>";
            echo "<td>"."$row[id]"." </td>";
            echo "<td>"."$row[email]"." </td>";
            echo "<td>"."$row[contactNum]"." </td>";
            echo "<td>"."<span class='label label-success'>Active</span>"." </td>";
            echo "</tr>";
            echo "</tbody>";
            echo "</form>";
        }
        echo "</table>";
        echo "</div>";

    }else{
        echo"<div class='alert alert-danger' role='alert'>";
        echo "No results found";
        echo "</div>";

    }

?>

</body>
</html>
